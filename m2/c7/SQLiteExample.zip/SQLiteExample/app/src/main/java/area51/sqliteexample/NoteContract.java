package area51.sqliteexample;

/**
 * Created by alumno on 14/04/16.
 */
public class NoteContract {

    public static final String ID = "_id";
    public static final String TITLE = "title";
    public static final String CONTENT = "content";
    public static final String CREATION_TIMESTAMP = "creationTimeStamp";
    public static final String MODIFICATION_TIMESTAMP = "modificationTimeStamp";

}
